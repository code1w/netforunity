﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace ProtoBuf.unittest
{
    [TestFixture]
    public class FX11
    {
        [Test]
        public void RunFX11()
        {
            global::FX11.FX11_Program.Main();
        }
    }
}
